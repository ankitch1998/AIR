


public class Node                            
{
    String name;                                                           
    int distance;                              
    
                                               
    public Node(String name, int dist)
    {
        this.name = name;
        this.distance = dist;
    }
    
    public int getDistance() {
        return distance;
    }

    public String getName() {
        return name;
    }

    public void setDistance(int distance) {
        this.distance = distance;
    }

    public void setName(String name) {
        this.name = name;
    }
   
    
}
