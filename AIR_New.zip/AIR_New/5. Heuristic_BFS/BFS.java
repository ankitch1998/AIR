
import java.util.ArrayList;
import java.util.PriorityQueue;
import java.util.Scanner;
import javax.swing.JOptionPane;


public class BFS                   
{

    public static void main(String[] args)
    {
        
        
        int n;

         n=Integer.parseInt(JOptionPane.showInputDialog("Enter No of nodes"));        
        PriorityQueue<Node> pq = new PriorityQueue<>(new DistanceComparator());            
        ArrayList<Boolean> visited = new ArrayList<>(n);
        ArrayList<String> parent = new ArrayList<>(n);                                  
        for(int i=0;i<n;i++)
        {
            visited.add(false);                                                      
            parent.add("NIL");                                                            
        }
        
        Graph graph = new Graph(n);                                                        
        graph.initGraph();                                                               
        graph.displayGraph();                                                              
        
        String start, goal;                                                                
        start = JOptionPane.showInputDialog("Enter the name of start node : ");
        
        goal = JOptionPane.showInputDialog("Enter the name of goal node : ");
        
        
        pq.add(new Node(start,0));                                                       
        visited.set(graph.getIndex(start), true);                                        
        parent.set(graph.getIndex(start), "NIL");                                      
        System.out.println("\n\nPriority queue contents : \n");
        displayQueue(pq);
        
        while(!pq.isEmpty())                                                             
        {
            Node temp = pq.poll();                                                       
            displayQueue(pq);
            if(temp.getName().equals(goal))                                     
            {
      
                System.out.println("\nGoal node '"+temp.getName() + "'  found");
                break;
            }
            else
            {
                ArrayList<Node> neighbours = graph.getNeighbours(temp.getName());          
                for(Node n1:neighbours)                                                
                {
                    if(!visited.get(graph.getIndex(n1.getName())))                          
                    {
                        visited.set(graph.getIndex(n1.getName()), Boolean.TRUE);     
                        pq.add(n1);                                                        
                        parent.set(graph.getIndex(n1.getName()), temp.getName());          
                    }
                }
                displayQueue(pq);                                                       
            }
            
            
        }
        
        tracePath(parent,graph,goal);
    }
    
    
    private static void displayQueue(PriorityQueue<Node> pq)                          
    {
        
        for(Node n:pq)
        {
            System.out.print(n.getName()+"\t");
        }
       
        System.out.println("");
    }
    
    private static void tracePath(ArrayList<String> parent, Graph graph, String goal)   
    {
        System.out.println("\n\nPath : ");
        String path = goal;
        String temp = goal;
        while(!parent.get(graph.getIndex(temp)).equals("NIL"))                            
        {
            temp = parent.get(graph.getIndex(temp));
            path = temp + ", " + path;
        }
        
        System.out.println(path);
    }
    
    
    
}



