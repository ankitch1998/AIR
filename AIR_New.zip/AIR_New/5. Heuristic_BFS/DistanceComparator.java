
import java.util.Comparator;


public class DistanceComparator implements Comparator<Node>    
{

    @Override
    public int compare(Node o1, Node o2) {
        if(o1.getDistance() > o2.getDistance())
            return 1;
        else if(o1.getDistance() < o2.getDistance())
            return -1;
        return 0;
    }
    
}
