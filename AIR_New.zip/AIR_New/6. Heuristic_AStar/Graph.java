
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JOptionPane;


public class Graph {                                                 
    
    ArrayList<HeadNode> headNodesList;
    int n;
    
    public Graph(int size)                                     
    {
        this.n = size;
        headNodesList = new ArrayList<>();
    }
    
    public void initGraph()                                    
    {
        Scanner sc = new Scanner(System.in);
        for(int i=0;i<n;i++)                                        
        {
            
            HeadNode hn = new HeadNode();
            hn.setName(JOptionPane.showInputDialog("Enter the name of node " +(i+1)+" : "));
            hn.setHx(Integer.parseInt(JOptionPane.showInputDialog("Enter the heuristic value of node " +(i+1)+" : ")));
            headNodesList.add(hn);
          
        }
        for(int i=0;i<n;i++)
        {
            HeadNode tempHeadNode = headNodesList.get(i);
            
            while(true)                                         
            {
                String name = tempHeadNode.getName();
                String ans = JOptionPane.showInputDialog("\nDo you want to add any adjacent node to node "+ name + "? (y/n) : ");
                if(ans.equals("n")  || ans.equals("N"))
                    break;
           
                String tempName=JOptionPane.showInputDialog("Enter the name of adjacent node of "+ name + " : ");

                int tempDistance=Integer.parseInt(JOptionPane.showInputDialog("Enter distance between nodes " + name + " and " + tempName+ " :"));
                    
                tempHeadNode.setNodeInfo(tempName,tempDistance);
                headNodesList.set(i, tempHeadNode);
            
            }
        }
    }
    
    public void displayGraph()                                 
    {
        for(int i=0;i<n;i++)
        {
            HeadNode tempHeadNode = headNodesList.get(i);
            System.out.print("\n"+ tempHeadNode.getName() + " (hx = "+tempHeadNode.getHx()+") : ");
            tempHeadNode.displayNodeList();
        }
        System.out.println("");
    }
    
    public int getIndex(String name)                        
    {
        for(int i=0;i<n;i++)
        {
            HeadNode tempHeadNode = headNodesList.get(i);
            if(tempHeadNode.getName().equals(name))
                return i;
        }
        return -1;
    }
    
    public ArrayList getNeighbours(String node)                  
    {
        int headIndex=getIndex(node);
        return headNodesList.get(headIndex).getNodeList();
    }
    
    public void setGx(String name,int gx)                       
    {
        int index = getIndex(name);
        HeadNode node = headNodesList.get(index);
        node.setGx(gx);
        headNodesList.set(index, node);
    }
    
    public HeadNode getHeadNode (String name){               
        return headNodesList.get(getIndex(name));
    }
    
    public void setFx(Node neighbour, HeadNode curr)          
    {
        int tempGx = curr.getGx() + neighbour.getDistance();    
        HeadNode adj = getHeadNode(neighbour.getName());         
        if(tempGx >= adj.getGx())                                
            return;
        
        adj.setGx(tempGx);                                         
        headNodesList.set(getIndex(adj.getName()), adj);       
    }
}
