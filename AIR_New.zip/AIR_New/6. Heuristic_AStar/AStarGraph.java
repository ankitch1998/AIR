
import java.util.ArrayList;
import java.util.PriorityQueue;
import javax.swing.JOptionPane;


public class AStarGraph {

    
    public static void main(String[] args) {
      
        int n;

         n=Integer.parseInt(JOptionPane.showInputDialog("Enter No of nodes"));             
        
         PriorityQueue<HeadNode> open = new PriorityQueue<>(new FxComparator());             
        ArrayList<HeadNode> closed = new ArrayList<>(n);                                    
        ArrayList<String> parent = new ArrayList<>(n);                                     
        for(int i=0;i<n;i++)
        {
            parent.add("NIL");                                                             
        }
        
        Graph graph = new Graph(n);                                                         
        graph.initGraph();                                                                 
        graph.displayGraph();                                                               
        
        String start, goal;                                                              
        start = JOptionPane.showInputDialog("Enter the name of start node : ");
        
        goal = JOptionPane.showInputDialog("Enter the name of goal node : ");
        
        graph.setGx(start, 0);                                                             
        open.add(graph.getHeadNode(start));                                                 
        parent.set(graph.getIndex(start), "NIL");                                          

        displayQueue(open);
        displayClosed(closed);
        
        while(!open.isEmpty())                                                             
        {
            HeadNode temp = open.poll();                                                   
            closed.add(temp);                                                               
            displayQueue(open);
            displayClosed(closed);
            if(temp.getName().equals(goal))                                              
            {
  
                System.out.println("\nGoal node '"+temp.getName() + "'  found");
                break;
            }
            else
            {
                ArrayList<Node> neighbours = temp.getNodeList();                           
                for(Node n1:neighbours)                                                    
                {
                    if(inClosed(n1.getName(), closed))                                      
                        continue;
                    if(!inOpen(n1.getName(), open))                                        
                    {
                      
                        graph.setFx(n1,temp);                                           
                        open.add(graph.getHeadNode(n1.getName()));                         
                        parent.set(graph.getIndex(n1.getName()), temp.getName());     
                    }
                }
                displayQueue(open);
            }
         
            
        }
        
        tracePath(parent, graph, goal);
    }
    
    
    private static void displayQueue(PriorityQueue<HeadNode> open)                    
    {
        System.out.print("\nOpen List : ");
        if(open.isEmpty())
        {
            System.out.println("Empty");
            return;
        }
        for(HeadNode n: open)
        {
            System.out.print(n.getName()+"\t");
        }
        System.out.println("");
    }
    
    private static void displayClosed(ArrayList<HeadNode> closed)                        
    {
        System.out.print("\nClosed List : ");
        if(closed.isEmpty())
        {
            System.out.println("Empty");
            return;
        }
        for(HeadNode n: closed)
        {
            System.out.print(n.getName()+"\t");
        }
        System.out.println("");
    }
    
    private static boolean inClosed(String name, ArrayList<HeadNode> closed)         
    {
        for(HeadNode n: closed)
        {
            if(n.getName().equals(name))
                return true;
        }
        return false;
    }
    
    private static boolean inOpen(String name, PriorityQueue<HeadNode> open)         
    {
        for(HeadNode n: open)
        {
            if(n.getName().equals(name))
                return true;
        }
        return false;
    }
    
    private static void tracePath(ArrayList<String> parent, Graph graph, String goal)    
    {
        System.out.println("\n\nPath : ");
        String path = goal;
        String temp = goal;
        while(!parent.get(graph.getIndex(temp)).equals("NIL"))                           
        {
            temp = parent.get(graph.getIndex(temp));
            path = temp + ", " + path;
        }
        
        System.out.println(path);
    }
}

