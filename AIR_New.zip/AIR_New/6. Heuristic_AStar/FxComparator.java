
import java.util.Comparator;


public class FxComparator implements Comparator<HeadNode>          
{

    @Override
    public int compare(HeadNode o1, HeadNode o2) {
        if(o1.getFx()> o2.getFx())
            return 1;
        else if(o1.getFx() < o2.getFx())
            return -1;
        return 0;
    }
    
}
