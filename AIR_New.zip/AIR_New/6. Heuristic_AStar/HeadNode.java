
import java.util.ArrayList;
import java.util.Iterator;


public class HeadNode                                   
{
    private String name;                                    
    private int gx;                                          
    private int hx;                                        
    private int fx;                                           
    private ArrayList<Node> adjnodes = new ArrayList<>();     
    
    public HeadNode()                                       
    {
        gx=hx=999;
        fx = gx+hx;
    }

    public int getGx() {
        return gx;
    }

    public void setGx(int gx) {                           
        this.gx = gx;
        setFx(this.gx+hx);
        System.out.println("\nFx of node "+this.name+" = "+this.fx);
    }

    public int getHx() {                                  
        return hx;
    }

    public void setHx(int hx) {                               
        this.hx = hx;
        setFx(this.hx+gx);
    }

    public int getFx() {
        return fx;
    }

    public void setFx(int fx) {
        this.fx = fx;
    }
    
    
    
    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setNodeInfo(String name,int distance)       
    {
        Node n = new Node(name,distance);
        adjnodes.add(n);                                 
    }
 
    public ArrayList getNodeList()
    {
        return adjnodes;
    }
    
    public void displayNodeList()                
    {
                
        Iterator i = adjnodes.iterator();
        if(i.hasNext())
        {
            Node temp= (Node)i.next();
            System.out.print("("+temp.getName()+","+temp.getDistance()+")");
        
        }
        while(i.hasNext())
        {
            Node temp= (Node)i.next();
            System.out.print(", ("+temp.getName()+","+temp.getDistance()+")");
        }
    }
    
}
